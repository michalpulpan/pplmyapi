import logging
from .ppl import PPL

__version__ = (0, 0, 2)
__versionstr__ = '.'.join(map(str, __version__))
